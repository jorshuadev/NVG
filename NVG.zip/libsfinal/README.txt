README.txt

Requirements - Java 17.0.14 or newer

Open "libs" folder, then run the "Run.bat" batch file, if this fails the batch file may need to be ran as administrator.

